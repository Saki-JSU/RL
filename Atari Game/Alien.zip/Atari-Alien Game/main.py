# Atari Game: Alien
import copy
from collections import namedtuple
from itertools import count
import math
import random
import numpy as np 
import time

import gym

from wrappers import *

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as T


# define
Experience = namedtuple('Experience',
                        ('state', 'action', 'next_state', 'reward'))


# DQN model
class DQN(nn.Module):
    def __init__(self, in_channels=4, n_actions=18):

        # in_channels (int): number of input channels
        # input is [4, 84, 84]
        # n_actions (int): number of outputs

        super(DQN, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels, 32, kernel_size=8, stride=4),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2)
        )
        # self.bn1 = nn.BatchNorm2d(32)
        self.conv2 = nn.Sequential(
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(inplace=True),
        )
        # self.bn2 = nn.BatchNorm2d(64)
        self.conv3 = nn.Sequential(
            nn.Conv2d(64, 64, kernel_size=2, stride=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2)
        )
        # self.bn3 = nn.BatchNorm2d(64)
        self.fc4 = nn.Linear(1 * 1 * 64, 64)
        self.head = nn.Linear(64, n_actions)

    def forward(self, x):
        x = x.float() / 255
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = F.relu(self.fc4(x.view(x.size(0), -1)))
        return self.head(x)


# memory buffer
class ReplayMemory(object):
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.position = 0

    def push(self, *args):
        if len(self.memory) < self.capacity:
            self.memory.append(None)   # add a none position
        self.memory[self.position] = Experience(*args)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)


# select action
# epsilon greedy algorithm
def select_action(state):
    global steps_done
    sample = random.random()
    steps_done += 1
    if sample > EPS_threshold:
        # greedy action with probability EPS_threshold
        with torch.no_grad():
            return policy_net(state.to(device)).max(1)[1].view(1, 1)
    else:
        # random action with probability 1-EPS_threshold
        return torch.tensor([[random.randrange(18)]], device=device, dtype=torch.long)


# optimization
def optimize_model():
    exps = memory.sample(BATCH_SIZE)
    """
    zip(*transitions) unzips the transitions into
    Transition(*) creates new named tuple
    batch.state - tuple of all the states (each state is a tensor)
    batch.next_state - tuple of all the next states (each state is a tensor)
    batch.reward - tuple of all the rewards (each reward is a float)
    batch.action - tuple of all the actions (each action is an int)    
    """
    batch = Experience(*zip(*exps))
    
    actions = tuple((map(lambda a: torch.tensor([[a]], device=device), batch.action)))
    rewards = tuple((map(lambda r: torch.tensor([r], device=device), batch.reward)))

    non_final_mask = torch.tensor(
        tuple(map(lambda s: s is not None, batch.next_state)),
        device=device, dtype=torch.bool)
    
    non_final_next_states = torch.cat([s for s in batch.next_state
                                       if s is not None]).to(device)

    state_batch = torch.cat(batch.state).to(device)
    action_batch = torch.cat(actions)
    reward_batch = torch.cat(rewards)
    
    state_action_values = policy_net(state_batch).gather(1, action_batch)
    
    next_state_values = torch.zeros(BATCH_SIZE, device=device)
    next_state_values[non_final_mask] = target_net(non_final_next_states).max(1)[0].detach()
    expected_state_action_values = (next_state_values * GAMMA) + reward_batch

    # loss function
    loss = F.smooth_l1_loss(state_action_values, expected_state_action_values.unsqueeze(1))

    # optimizer
    optimizer.zero_grad()
    loss.backward()
    for param in policy_net.parameters():
        param.grad.data.clamp_(-1, 1)
    optimizer.step()


# get current state
def get_state(obs):
    state = np.array(obs)
    state = state.transpose((2, 0, 1))
    state = torch.from_numpy(state)
    return state.unsqueeze(0)


# training
def train(env, n_episodes, render=True):
    restart = True
    total_reward = 0.0
    for episode in range(n_episodes):
        obs = env.reset()
        state = get_state(obs)
        # A new game with three lives
        if restart:
            total_reward = 0.0

        for t in count():
            action = select_action(state)

            if render:
                env.render()

            obs, reward, done, info = env.step(action)

            total_reward += reward

            if not done:
                next_state = get_state(obs)
            else:
                next_state = None

            reward = torch.tensor([reward], device=device)

            # save memory
            memory.push(state, action.to(device), next_state, reward.to(device))

            state = next_state

            if len(memory) > BATCH_SIZE:
                optimize_model()

                # update parameters of target net from policy net
                if steps_done % TARGET_UPDATE == 0:
                    target_net.load_state_dict(policy_net.state_dict())

            if done:
                break

        if info.get('ale.lives') == 0:
            restart = True
        else:
            restart = False

        if episode % 3 == 2:
            print('Total steps: {} \t Episode: {}/{} \t Total reward: {}'
                  .format(steps_done, episode, total_episode, total_reward))
    env.close()
    return


# test
def test(env, n_episodes, policy, render=False):
    env = gym.wrappers.Monitor(env, './videos/' + 'dqn_alien_video', force=True)
    print('start testing...')
    for episode in range(n_episodes):
        obs = env.reset()
        state = get_state(obs)
        total_reward = 0.0
        for t in count():
            action = policy(state.to(device)).max(1)[1].view(1,1)

            if render:
                env.render()
                time.sleep(0.02)

            obs, reward, done, info = env.step(action)

            total_reward += reward

            if not done:
                next_state = get_state(obs)
            else:
                next_state = None

            state = next_state

            if done:
                print("Finished Episode {} with reward {}".format(episode, total_reward))
                break

    env.close()
    print('test ended.')
    return


if __name__ == '__main__':
    # set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # hyperparameters
    BATCH_SIZE = 32
    GAMMA = 0.99
    EPS_threshold = 0.98
    TARGET_UPDATE = 1000
    lr = 1e-4
    MEMORY_SIZE = 1000
    total_episode = 100

    # create networks
    policy_net = DQN(n_actions=18).to(device)
    target_net = DQN(n_actions=18).to(device)
    target_net.load_state_dict(policy_net.state_dict())

    # setup optimizer
    optimizer = optim.Adam(policy_net.parameters(), lr=lr)

    steps_done = 0

    # create environment
    env = gym.make("Alien-v0")
    env = make_env(env)

    # initialize replay memory
    memory = ReplayMemory(MEMORY_SIZE)
    
    # train model
    train(env, total_episode)
    torch.save(policy_net, "dqn_alien_model")
    policy_net = torch.load("dqn_alien_model")
    test(env, 3, policy_net)

